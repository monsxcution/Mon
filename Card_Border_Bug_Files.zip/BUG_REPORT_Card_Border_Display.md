# BÁO CÁO LỖI: VIỀN CARD KHÔNG HIỂN THỊ THEO TRẠNG THÁI

## 📋 **Tóm tắt lỗi**
- **Vấn đề**: Viền card không thay đổi màu theo trạng thái tài khoản
- **Mức độ**: Nghiêm trọng - ảnh hưởng đến UX
- **Trạng thái**: Đang điều tra

## 🔍 **Mô tả chi tiết**

### **Kỳ vọng:**
- Card có viền đỏ khi status = `die`, `disabled`, `banned`, `blocked`
- Card có viền cam khi có thông báo (notice)
- Card có viền xanh khi WeChat + Anniversary + HK (+852)
- Card có viền trắng khi WeChat + Anniversary + không HK

### **Thực tế:**
- Tất cả card đều có viền mặc định (không có màu)
- Không có sự thay đổi visual khi cập nhật trạng thái

## 🛠️ **Phân tích kỹ thuật**

### **1. Logic JavaScript (app/static/js/mxh.js)**
```javascript
// Logic xác định viền - DÒNG 349-371
const isDie = ['disabled', 'die', 'banned', 'blocked']
    .includes(String(account.status || '').toLowerCase()) || !!account.die_date;

const hasNotice = !!(noticeObj && (noticeObj.enabled === true || noticeObj.enabled === 1 || Number(noticeObj.days) > 0));

// Gán class viền theo ưu tiên: Đỏ > Cam > Xanh > Trắng
if (isDie) {
    borderClass = 'mxh-border-red';
} else if (hasNotice) {
    borderClass = 'mxh-border-orange';
} else if (isWechat && ageDays >= 365 && isHK) {
    borderClass = 'mxh-border-green';
} else if (isWechat && ageDays >= 365 && !isHK) {
    borderClass = 'mxh-border-white';
}
```

**✅ Logic JavaScript đã đúng**

### **2. HTML Template (app/static/js/mxh.js)**
```javascript
// Dòng 533 - Áp dụng borderClass vào HTML
<div class="card tool-card mxh-card ${borderClass} ${extraClass}" ...>
```

**✅ HTML template đã đúng**

### **3. CSS Styling (app/static/css/mxh.css)**
```css
/* Dòng 41-91 - CSS với high specificity */
.tool-card.mxh-card.mxh-border-red {
    border: 2px solid #ff4d4f !important;
    box-shadow: 0 0 0 1px rgba(255,77,79,.35), 0 0 14px rgba(255,77,79,.5), 0 0 28px rgba(255,77,79,.3) !important;
}
```

**✅ CSS đã có high specificity và !important**

## 🐛 **Nguyên nhân có thể**

### **1. Browser Cache**
- CSS cũ có thể đang được cache
- JavaScript cũ có thể đang được cache

### **2. CSS Specificity Conflict**
- Có thể có CSS khác override
- Cần kiểm tra CSS loading order

### **3. JavaScript Logic**
- Debug logs chưa được kiểm tra
- Logic có thể không chạy đúng

### **4. Data Issues**
- Account data có thể không đúng format
- Status field có thể null/undefined

## 🔧 **Các bước debug đã thực hiện**

### **1. ✅ Thêm Debug Logs**
```javascript
console.log(`Account ${account.id}: status=${account.status}, isDie=${isDie}, hasNotice=${hasNotice}, borderClass=${borderClass}`);
```

### **2. ✅ Tăng CSS Specificity**
- Thay đổi từ `.mxh-card.mxh-border-red`
- Thành `.tool-card.mxh-card.mxh-border-red`

### **3. ✅ Test API Endpoints**
- Status update: ✅ Hoạt động
- Rescue: ✅ Hoạt động
- Data reload: ✅ Hoạt động

## 📊 **Test Cases**

### **Test 1: Status Update**
```bash
POST /mxh/api/accounts/8/status
Body: {"status":"die"}
Result: ✅ 200 OK - "Đã cập nhật trạng thái thành die"
```

### **Test 2: Rescue Success**
```bash
POST /mxh/api/accounts/8/rescue  
Body: {"result":"success"}
Result: ✅ 200 OK - "Cứu thành công!"
```

## 🎯 **Giải pháp đề xuất**

### **1. Kiểm tra Debug Logs**
- Mở Developer Console
- Right-click vào card
- Xem console logs để kiểm tra:
  - `status` value
  - `isDie` calculation
  - `borderClass` assignment

### **2. Force CSS Reload**
- Hard refresh (Ctrl+F5)
- Clear browser cache
- Check Network tab for CSS loading

### **3. Kiểm tra HTML Output**
- Inspect element trên card
- Xem class `mxh-border-red` có được apply không
- Check computed styles

### **4. CSS Override Check**
- Kiểm tra CSS khác có override không
- Thêm `!important` nếu cần
- Kiểm tra CSS loading order

## 📁 **Files liên quan**

### **Core Files:**
- `app/static/js/mxh.js` (Dòng 349-371, 533)
- `app/static/css/mxh.css` (Dòng 41-91)
- `app/mxh_api.py` (Status/Rescue endpoints)

### **Template Files:**
- `app/templates/mxh.html` (Context menu)

## 🚨 **Mức độ ưu tiên: CAO**

Lỗi này ảnh hưởng trực tiếp đến:
- User Experience
- Visual feedback
- Status indication
- Workflow efficiency

## 📝 **Next Steps**

1. **Immediate**: Kiểm tra debug logs trong browser console
2. **Short-term**: Force CSS reload và test
3. **Long-term**: Implement CSS versioning để tránh cache issues

---
**Reported by**: AI Assistant  
**Date**: 2025-10-19  
**Status**: Under Investigation
