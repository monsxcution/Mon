# BÁO CÁO YÊU CẦU HOÀN THIỆN CHỨC NĂNG MXH MODULE

## 📋 TỔNG QUAN
- **Mục tiêu**: Hoàn thiện 100% chức năng giống file mẫu MXH_Old
- **Trạng thái hiện tại**: Đã có cơ bản, cần bổ sung các chức năng nâng cao
- **File tham khảo**: `MXH_Old/mxh.html` (đã tải lên sẵn)

## 🎯 CÁC CHỨC NĂNG CẦN BỔ SUNG

### 1. **CONTEXT MENU TRẠNG THÁI** 
**Mục tiêu**: Context menu "Trạng Thái" với submenu đầy đủ

#### 1.1 Cấu trúc HTML cần thêm:
```html
<!-- Trạng Thái (with submenu) -->
<div class="menu-item has-submenu" id="status-submenu-item">
    <i class="bi bi-circle-fill me-2"></i> Trạng Thái
    <i class="bi bi-chevron-right ms-auto"></i>
    <div class="submenu" id="status-submenu">
        <div class="menu-item status-normal" data-action="status-available">
            <i class="bi bi-check-circle-fill me-2 text-success"></i> Available
        </div>
        <div class="menu-item status-normal" data-action="status-die">
            <i class="bi bi-x-circle-fill me-2 text-danger"></i> Die
        </div>
        <div class="menu-item status-normal" data-action="status-disabled">
            <i class="bi bi-slash-circle me-2 text-warning"></i> Vô hiệu hóa
        </div>
        <div class="menu-item status-rescue" data-action="rescue-success" style="display: none;">
            <i class="bi bi-heart-fill me-2 text-success"></i> Được Cứu
        </div>
        <div class="menu-item status-rescue" data-action="rescue-failed" style="display: none;">
            <i class="bi bi-heartbreak-fill me-2 text-danger"></i> Cứu Thất Bại
        </div>
    </div>
</div>
```

#### 1.2 Logic JavaScript cần implement:
- **Dynamic submenu**: Khi status = 'disabled' → hiện rescue options, ẩn normal options
- **Status switching**: Available ↔ Die ↔ Disabled
- **Rescue logic**: Cứu thành công → chuyển về active, Cứu thất bại → tăng rescue_count

#### 1.3 API endpoints cần có:
```javascript
// Toggle status
POST /mxh/api/accounts/{id}/toggle-status

// Rescue operations  
POST /mxh/api/accounts/{id}/rescue
Body: { "result": "success" | "failed" }

// Change status directly
PUT /mxh/api/accounts/{id}
Body: { "status": "available" | "die" | "disabled" }
```

### 2. **CHỨC NĂNG ĐỔI SỐ HIỆU**
**Mục tiêu**: Hoàn thiện context menu "Đổi số hiệu"

#### 2.1 Modal HTML cần thêm:
```html
<div class="modal fade" id="change-card-number-modal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-123 me-2"></i>Đổi Số Hiệu Card</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label for="new-card-number" class="form-label">Số hiệu mới</label>
                    <input type="number" class="form-control" id="new-card-number" 
                           placeholder="Nhập số hiệu mới..." min="1" required>
                    <div class="form-text">Nhập số hiệu mới cho card này</div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                <button type="button" class="btn btn-primary" id="apply-card-number-btn">Áp Dụng</button>
            </div>
        </div>
    </div>
</div>
```

#### 2.2 Logic JavaScript:
```javascript
function changeCardNumber(e) {
    if (e) {
        e.preventDefault();
        e.stopPropagation();
    }
    if (!currentContextAccountId) return;
    const modal = new bootstrap.Modal(document.getElementById('change-card-number-modal'));
    modal.show();
    hideUnifiedContextMenu();
}

// Event listener cho nút Apply
document.getElementById('apply-card-number-btn').addEventListener('click', async () => {
    if (!currentContextAccountId) return;
    
    const newNumber = document.getElementById('new-card-number').value;
    if (!newNumber) return;
    
    // Instant local update
    const accountIndex = mxhAccounts.findIndex(acc => acc.id === currentContextAccountId);
    if (accountIndex !== -1) {
        mxhAccounts[accountIndex].card_name = newNumber;
    }
    
    bootstrap.Modal.getInstance(document.getElementById('change-card-number-modal')).hide();
    renderMXHAccounts();
    
    // API call
    try {
        const response = await fetch(`/mxh/api/accounts/${currentContextAccountId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ card_name: newNumber })
        });
        
        if (response.ok) {
            showToast('✅ Đã đổi số hiệu!', 'success');
        } else {
            showToast('Lỗi khi đổi số hiệu!', 'error');
            await loadMXHData(false);
        }
    } catch (error) {
        showToast('Lỗi kết nối!', 'error');
        await loadMXHData(false);
    }
});
```

### 3. **CHỨC NĂNG XÓA CARD**
**Mục tiêu**: Context menu "Xóa Card" với confirmation

#### 3.1 HTML cần thêm:
```html
<div class="menu-item" data-action="delete" style="color: #dc3545;">
    <i class="bi bi-trash-fill me-2"></i> Xóa Card
</div>
```

#### 3.2 Logic JavaScript:
```javascript
function showDeleteConfirm(e) {
    if (e) {
        e.preventDefault();
        e.stopPropagation();
    }
    if (!currentContextAccountId) return;
    
    const account = mxhAccounts.find(acc => acc.id === currentContextAccountId);
    if (!account) return;
    
    if (confirm(`Bạn có chắc muốn xóa card "${account.card_name}"?\n\nHành động này sẽ xóa:\n- Thông tin tài khoản chính và phụ\n- Lịch sử quét QR\n- Trạng thái vô hiệu hóa\n- Lịch sử vi phạm và cứu tài khoản\n- Tất cả dữ liệu khác`)) {
        deleteAccount();
    }
    hideUnifiedContextMenu();
}

async function deleteAccount() {
    if (!currentContextAccountId) return;
    
    try {
        const response = await fetch(`/mxh/api/accounts/${currentContextAccountId}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showToast('✅ Đã xóa card!', 'success');
            await loadMXHData(true);
        } else {
            showToast('Lỗi khi xóa card!', 'error');
        }
    } catch (error) {
        showToast('Lỗi kết nối!', 'error');
    }
}
```

### 4. **LOGIC HIỂN THỊ NGÀY TẠO TÀI KHOẢN**
**Mục tiêu**: Hiển thị tuổi tài khoản với logic đặc biệt cho Hong Kong

#### 4.1 Logic tính toán tuổi:
```javascript
// Trong renderMXHAccounts(), phần tính accountAgeDisplay
if (account.platform === 'wechat' && account.wechat_created_year) {
    const createdDate = new Date(account.wechat_created_year, (account.wechat_created_month || 1) - 1, account.wechat_created_day || 1);
    const diffDays = Math.ceil((now - createdDate) / (1000 * 60 * 60 * 24));
    
    if (diffDays >= 365) {
        const years = Math.floor(diffDays / 365);
        const months = Math.floor((diffDays % 365) / 30);
        
        if (years >= 1) {
            accountAgeDisplay = `${years}Y${months > 0 ? `+${months}M` : ''}`;
            ageColor = '#2fe56a'; // Xanh lá cho anniversary
        } else {
            accountAgeDisplay = `${months}M`;
            ageColor = '#6c757d';
        }
    } else if (diffDays >= 30) {
        const months = Math.floor(diffDays / 30);
        accountAgeDisplay = `${months}M`;
        ageColor = '#6c757d';
    } else {
        accountAgeDisplay = `${diffDays}D`;
        ageColor = '#6c757d';
    }
}
```

#### 4.2 Logic Hong Kong + Anniversary:
```javascript
// Trong phần tính borderClass
const isWechat = String(account.platform || '').toLowerCase() === 'wechat';
const isHK = /^\+?852/.test(account.phone || '');
const y = +account.wechat_created_year || 0;
const m = (+account.wechat_created_month || 1) - 1;
const d = +account.wechat_created_day || 1;
const ageDays = isFinite(new Date(y, m, d)) ? Math.floor((Date.now() - new Date(y, m, d).getTime()) / 86400000) : 0;

// Gán class viền theo ưu tiên: Đỏ > Cam > Xanh > Trắng
let borderClass = '';
if (isDie) {
    borderClass = 'mxh-border-red';
} else if (hasNotice) {
    borderClass = 'mxh-border-orange';
} else if (isWechat && ageDays >= 365 && isHK) {
    borderClass = 'mxh-border-green'; // Hong Kong + 1 năm = xanh
} else {
    borderClass = 'mxh-border-white';
}
```

#### 4.3 Logic blink cho tài khoản 1 năm (không phải Hong Kong):
```javascript
// Trong phần tính extraClass cho blink
if (account.platform === 'wechat' && account.wechat_created_year) {
    const createdDate = new Date(account.wechat_created_year, account.wechat_created_month - 1, account.wechat_created_day);
    const diffDays = Math.ceil((now - createdDate) / (1000 * 60 * 60 * 24));
    if (diffDays >= 365) {
        // Check if Hong Kong number
        const primaryPhone = (account.phone || '').replace(/[\s+]/g, '');
        const isHongKongNumber = primaryPhone.startsWith('852');
        if (!isHongKongNumber) {
            extraClass = 'anniversary-blink'; // Blink nếu 1 năm + không phải HK
        }
    }
}
```

#### 4.4 CSS cho anniversary blink:
```css
.anniversary-blink {
    animation: anniversary-pulse 2s ease-in-out infinite;
}

@keyframes anniversary-pulse {
    0%, 100% { 
        box-shadow: 0 0 0 0 rgba(47, 229, 106, 0.7);
    }
    50% { 
        box-shadow: 0 0 20px 4px rgba(47, 229, 106, 0.9);
    }
}
```

### 5. **NHẬN DẠNG SỐ ĐIỆN THOẠI HONG KONG**
**Mục tiêu**: Tự động nhận dạng số Hong Kong (+852)

#### 5.1 Logic nhận dạng:
```javascript
function isHongKongNumber(phone) {
    if (!phone) return false;
    const cleanPhone = phone.replace(/[\s+]/g, '');
    return cleanPhone.startsWith('852');
}

// Sử dụng trong logic borderClass
const isHK = isHongKongNumber(account.phone);
```

#### 5.2 Validation trong form:
```javascript
// Trong form thêm/sửa tài khoản
function validatePhoneNumber(phone) {
    if (!phone) return true;
    
    const cleanPhone = phone.replace(/[\s+]/g, '');
    
    // Hong Kong: +852 xxxx xxxx
    if (cleanPhone.startsWith('852')) {
        return cleanPhone.length >= 11; // 852 + 8 digits
    }
    
    // Vietnam: +84 xxxx xxxxx
    if (cleanPhone.startsWith('84')) {
        return cleanPhone.length >= 10; // 84 + 9 digits
    }
    
    return true; // Other countries
}
```

## 🎨 CSS CẦN BỔ SUNG

### Border classes:
```css
.mxh-border-red { border: 2px solid #dc3545 !important; }
.mxh-border-orange { border: 2px solid #ff8c00 !important; }
.mxh-border-green { border: 2px solid #28a745 !important; }
.mxh-border-white { border: 2px solid #ffffff !important; }
```

### Anniversary blink:
```css
.anniversary-blink {
    animation: anniversary-pulse 2s ease-in-out infinite;
}

@keyframes anniversary-pulse {
    0%, 100% { 
        box-shadow: 0 0 0 0 rgba(47, 229, 106, 0.7);
    }
    50% { 
        box-shadow: 0 0 20px 4px rgba(47, 229, 106, 0.9);
    }
}
```

## 🔧 API ENDPOINTS CẦN CÓ

### 1. Toggle Status:
```python
@mxh_bp.route("/api/accounts/<int:account_id>/toggle-status", methods=["POST"])
def toggle_account_status(account_id):
    # Logic toggle status: active ↔ disabled
```

### 2. Rescue Account:
```python
@mxh_bp.route("/api/accounts/<int:account_id>/rescue", methods=["POST"])
def rescue_account(account_id):
    # Logic rescue: success/failed
```

### 3. Change Status:
```python
@mxh_bp.route("/api/accounts/<int:account_id>", methods=["PUT"])
def update_account(account_id):
    # Logic update status directly
```

### 4. Delete Account:
```python
@mxh_bp.route("/api/accounts/<int:account_id>", methods=["DELETE"])
def delete_account(account_id):
    # Logic delete account
```

## 📋 CHECKLIST HOÀN THIỆN

### Frontend (JavaScript):
- [ ] Context menu "Trạng Thái" với submenu
- [ ] Logic dynamic submenu (rescue khi disabled)
- [ ] Modal "Đổi số hiệu" 
- [ ] Confirmation dialog "Xóa Card"
- [ ] Logic tính tuổi tài khoản
- [ ] Logic Hong Kong number detection
- [ ] Anniversary blink effect
- [ ] Status switching logic

### Backend (Python):
- [ ] API toggle status
- [ ] API rescue account  
- [ ] API update account
- [ ] API delete account
- [ ] Validation Hong Kong numbers

### CSS:
- [ ] Border classes (red, orange, green, white)
- [ ] Anniversary blink animation
- [ ] Status icons styling

## 🎯 KẾT QUẢ MONG ĐỢI

Sau khi hoàn thiện, hệ thống sẽ có:

1. **Context menu đầy đủ** như file mẫu MXH_Old
2. **Logic trạng thái phức tạp** với rescue options
3. **Hiển thị tuổi tài khoản** với logic Hong Kong
4. **Animation anniversary** cho tài khoản 1 năm
5. **Nhận dạng số Hong Kong** tự động
6. **Chức năng đổi số hiệu** hoàn chỉnh
7. **Xóa card** với confirmation

---
*Báo cáo được tạo để hướng dẫn AI ChatGPT implement các chức năng còn thiếu*
