/**
 * NotesEnhancer – áp dụng cho vùng ghi chú contenteditable có class .mxh-note-edit
 * - Tự nhận diện @username (3–32 ký tự chữ/số/_)
 * - Tự nhận diện dãy số >= 4 chữ số
 * - Click token để copy
 * - Highlight & scroll khi tìm kiếm
 */
(() => {
  const MENTION_RE   = /(^|[^A-Za-z0-9_])(@[A-Za-z0-9_]{3,32})(?![A-Za-z0-9_])/g;
  const DIGITS_RE    = /(?<![A-Za-z0-9])(\d{4,})(?![A-Za-z0-9])/g;
  const LS_QUERY_KEY = 'mxh_last_search_query'; // nếu muốn truyền query giữa trang MXH ↔ Ghi chú

  // ===== Helper: clipboard =====
  async function copyText(text) {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
      } else {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.left = '-9999px';
        document.body.appendChild(ta);
        ta.focus(); ta.select();
        document.execCommand('copy');
        ta.remove();
      }
      toast('Đã copy: ' + text);
    } catch {
      toast('Copy thất bại');
    }
  }

  // Toast tối giản (không phụ thuộc framework)
  let toastTimer = null;
  function toast(msg) {
    let t = document.getElementById('__note_toast');
    if (!t) {
      t = document.createElement('div');
      t.id = '__note_toast';
      t.style.cssText = 'position:fixed;bottom:16px;left:50%;transform:translateX(-50%);padding:8px 12px;background:#000;color:#fff;border-radius:8px;z-index:2147483647;opacity:.9;font-size:12px;';
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.style.display = 'block';
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (t.style.display = 'none'), 1200);
  }

  // ===== Helper: caret save/restore theo offset ký tự trong container =====
  function saveSelection(container) {
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return null;
    const range = sel.getRangeAt(0);
    const preRange = range.cloneRange();
    preRange.selectNodeContents(container);
    preRange.setEnd(range.startContainer, range.startOffset);
    const start = preRange.toString().length;

    const endRange = sel.getRangeAt(0).cloneRange();
    const preRange2 = endRange.cloneRange();
    preRange2.selectNodeContents(container);
    preRange2.setEnd(endRange.endContainer, endRange.endOffset);
    const end = preRange2.toString().length;

    return { start, end };
  }

  function setSelection(container, start, end) {
    const range = document.createRange();
    const sel = window.getSelection();
    let current = 0;

    function traverse(node) {
      if (node.nodeType === Node.TEXT_NODE) {
        const len = node.textContent.length;
        const next = current + len;

        if (start >= current && start <= next) {
          range.setStart(node, Math.max(0, start - current));
        }
        if (end >= current && end <= next) {
          range.setEnd(node, Math.max(0, end - current));
        }
        current = next;
      } else {
        for (const child of node.childNodes) traverse(child);
      }
    }

    traverse(container);
    sel.removeAllRanges();
    sel.addRange(range);
  }

  // ===== Core: wrap token trong text node (bỏ qua vùng đã wrap) =====
  function wrapSmartTokens(root) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: (n) => {
        if (!n.nodeValue || !n.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
        // Không xử lý nếu text nằm TRONG smart-token hoặc search-hit
        if (n.parentElement && (n.parentElement.closest('.smart-token') || n.parentElement.closest('.search-hit'))) {
          return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_ACCEPT;
      }
    });

    const toProcess = [];
    while (walker.nextNode()) toProcess.push(walker.currentNode);

    for (const textNode of toProcess) {
      const text = textNode.nodeValue;
      const hasMention = MENTION_RE.test(text);
      const hasDigits  = DIGITS_RE.test(text);
      if (!hasMention && !hasDigits) { MENTION_RE.lastIndex = 0; DIGITS_RE.lastIndex = 0; continue; }

      const frag = document.createDocumentFragment();
      let lastIndex = 0;

      function pushWrap(full, token, index, length, className) {
        if (index > lastIndex) frag.appendChild(document.createTextNode(text.slice(lastIndex, index)));
        const span = document.createElement('span');
        span.className = 'smart-token ' + className;
        span.textContent = token;
        span.dataset.token = token;
        frag.appendChild(span);
        lastIndex = index + length;
      }

      // Gộp hai regex theo thứ tự xuất hiện
      const matches = [];
      MENTION_RE.lastIndex = 0; DIGITS_RE.lastIndex = 0;
      let m;
      while ((m = MENTION_RE.exec(text))) {
        const token = m[2]; // nhóm @username
        matches.push({ index: m.index + (m[1] ? m[1].length : 0), len: token.length, token, cls: 'mention' });
      }
      while ((m = DIGITS_RE.exec(text))) {
        const token = m[1];
        matches.push({ index: m.index + (m[0].length - token.length), len: token.length, token, cls: 'number' });
      }
      matches.sort((a,b) => a.index - b.index);

      for (const hit of matches) pushWrap(null, hit.token, hit.index, hit.len, hit.cls);
      if (lastIndex < text.length) frag.appendChild(document.createTextNode(text.slice(lastIndex)));

      textNode.replaceWith(frag);
    }
  }

  // ===== Highlight tìm kiếm (bôi đậm + cuộn tới) =====
  function highlightAndScroll(container, query) {
    // Xóa highlight cũ
    container.querySelectorAll('.search-hit').forEach(n => {
      const parent = n.parentNode;
      while (n.firstChild) parent.insertBefore(n.firstChild, n);
      parent.removeChild(n);
    });
    if (!query || !query.trim()) return;

    const q = query.trim();
    const re = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');

    const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT, {
      acceptNode: (n) => {
        if (!n.nodeValue || !n.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
        if (n.parentElement && (n.parentElement.closest('.smart-token'))) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      },
    });

    const firstHits = [];
    const toProcess = [];
    while (walker.nextNode()) toProcess.push(walker.currentNode);

    for (const textNode of toProcess) {
      const text = textNode.nodeValue;
      if (!re.test(text)) { re.lastIndex = 0; continue; }

      const frag = document.createDocumentFragment();
      let last = 0;
      re.lastIndex = 0;
      let m;
      while ((m = re.exec(text))) {
        if (m.index > last) frag.appendChild(document.createTextNode(text.slice(last, m.index)));
        const mark = document.createElement('mark');
        mark.className = 'search-hit';
        mark.textContent = m[0];
        frag.appendChild(mark);
        if (firstHits.length === 0) firstHits.push(mark);
        last = m.index + m[0].length;
      }
      if (last < text.length) frag.appendChild(document.createTextNode(text.slice(last)));
      textNode.replaceWith(frag);
    }

    if (firstHits[0]) {
      // Cuộn tới node đầu tiên
      const node = firstHits[0];
      const scrollParent = getScrollableParent(container) || container;
      const rect = node.getBoundingClientRect();
      const parentRect = scrollParent.getBoundingClientRect();
      const offset = rect.top - parentRect.top - parentRect.height / 2;
      scrollParent.scrollBy({ top: offset, behavior: 'smooth' });
    }
  }

  function getScrollableParent(el) {
    let p = el.parentElement;
    while (p) {
      const hs = window.getComputedStyle(p).overflowY;
      if ((hs === 'auto' || hs === 'scroll') && p.scrollHeight > p.clientHeight) return p;
      p = p.parentElement;
    }
    return document.scrollingElement || document.documentElement;
  }

  // ===== Init vào vùng .mxh-note-edit =====
  function initNoteArea(container) {
    if (!container) return;
    const debounced = debounce(() => {
      const sel = saveSelection(container);
      wrapSmartTokens(container);
      if (sel) setSelection(container, sel.start, sel.end);
    }, 250);

    // Lần đầu
    wrapSmartTokens(container);

    // Sau khi gõ / paste
    container.addEventListener('input', debounced);
    container.addEventListener('paste', () => setTimeout(debounced, 0));

    // Click để copy
    container.addEventListener('click', (e) => {
      const t = e.target.closest('.smart-token');
      if (!t) return;
      e.preventDefault();
      e.stopPropagation();
      copyText(t.dataset.token || t.textContent || '');
    });
  }

  // Debounce đơn giản
  function debounce(fn, ms) {
    let id = null;
    return (...args) => {
      clearTimeout(id);
      id = setTimeout(() => fn.apply(null, args), ms);
    };
  }

  // ===== API công khai để trang gọi =====
  window.NotesEnhancer = {
    initAll() {
      document.querySelectorAll('.mxh-note-edit').forEach(initNoteArea);
    },
    initOne(el) { initNoteArea(el); },
    setQueryAndHighlight(query, container = document.querySelector('.mxh-note-edit')) {
      if (query != null) localStorage.setItem(LS_QUERY_KEY, String(query));
      if (container) highlightAndScroll(container, query);
    },
    highlightFromStored(container = document.querySelector('.mxh-note-edit')) {
      const q = localStorage.getItem(LS_QUERY_KEY) || '';
      if (container) highlightAndScroll(container, q);
    },
  };

  // Auto-init khi DOM sẵn sàng (nếu trang Ghi chú load file này)
  document.addEventListener('DOMContentLoaded', () => {
    window.NotesEnhancer?.initAll();
    // Nếu MXH đã đẩy query vào localStorage, tự highlight luôn
    window.NotesEnhancer?.highlightFromStored();
  });
})();
